node-email-verification
=======================
Script to send and verify email account of user.

Tutorial link : http://wp.me/p4ISPV-39

How to use: 

You can get the script in two ways:

=> Either download the zip.

      OR
      
=> git clone https://github.com/codeforgeek/node-email-verification.git

Thanks.
